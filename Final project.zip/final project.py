import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk

# Function to calculate the total price
def calculate_total():
    coffee_price = coffee_prices[coffee_var.get()]
    add_ons_price = sum(add_on_prices[add_on] for add_on in add_on_vars if add_on_vars[add_on].get())
    total_price = coffee_price + add_ons_price
    result_label.config(text=f"Total Price: ${total_price:.2f}")

    # Generate order number and add to history
    order_number = len(order_history)
    order_history.append((order_number, coffee_var.get(), total_price))
    update_order_history()


# Function to clear the selections
def clear_order():
    coffee_var.set("Select a Coffee")
    for add_on in add_on_vars:
        add_on_vars[add_on].set(False)
    coffee_image_label.config(image="")  # Clear the coffee image
    result_label.config(text="")


# Function to update the coffee image
def update_coffee_image(event):
    selected_coffee = coffee_var.get()
    if selected_coffee in coffee_images:
        coffee_image_label.config(image=coffee_images[selected_coffee])
        coffee_image_label.image = coffee_images[selected_coffee]
    else:
        coffee_image_label.config(image="")


# Function to show order history in a new window
def show_order_history():
    history_window = tk.Toplevel(root)
    history_window.title("Order History")
    history_window.geometry("400x300")
    history_window.resizable(False, False)  # Make the window non-resizable

    # Create a listbox to display order history
    history_listbox = tk.Listbox(history_window, width=50, height=15)
    history_listbox.pack(pady=10)

    # Add the listbox to the history window as a global variable
    history_window.history_listbox = history_listbox

    # Button to close the history window
    close_button = tk.Button(history_window, text="Close", command=history_window.destroy)
    close_button.pack(pady=10)

    # Initially populate the listbox
    update_order_history(history_window)


# Function to update the order history
def update_order_history(history_window=None):
    if history_window and hasattr(history_window, "history_listbox"):
        history_listbox = history_window.history_listbox
        history_listbox.delete(0, tk.END)  # Clear the listbox before inserting new entries

        # Display each order in the listbox
        for order in order_history:
            order_number, coffee, total_price = order
            history_listbox.insert(tk.END, f"Order #{order_number}: {coffee} - ${total_price:.2f}")


# Prices for coffee and add-ons
coffee_prices = {
    "Espresso": 3.00,
    "Latte": 4.00,
    "Cappuccino": 4.50,
    "Americano": 3.50,
    "Flat White": 4.00,  # New coffee option
    "Mocha": 4.50,  # New coffee option
    "Macchiato": 4.25  # New coffee option
}

add_on_prices = {
    "Milk": 0.50,
    "Sugar": 0.25,
    "Whipped Cream": 0.75,
    "Extra Shot": 1.00,
    "Caramel": 0.75,  # New topping
    "Chocolate Syrup": 0.75  # New topping
}

# Order history list
order_history = []

# Main application window
root = tk.Tk()
root.title("CoffeeExpress")
root.geometry("700x750")  # Reduced window size
root.resizable(False, False)  # Disable resizing of main window

# Load and set the background image
background_image = Image.open("background.jpg")
background_photo = ImageTk.PhotoImage(background_image)

canvas = tk.Canvas(root, width=700, height=650)
canvas.pack(fill="both", expand=True)
canvas.create_image(0, 0, image=background_photo, anchor="nw")

# Load coffee images (after creating the root)
coffee_images = {
    "Espresso": ImageTk.PhotoImage(Image.open("espresso.png")),
    "Latte": ImageTk.PhotoImage(Image.open("latte.png")),
    "Cappuccino": ImageTk.PhotoImage(Image.open("cappuccino.png")),
    "Americano": ImageTk.PhotoImage(Image.open("americano.png")),
    "Flat White": ImageTk.PhotoImage(Image.open("flat_white.png")),  # New image for Flat White
    "Mocha": ImageTk.PhotoImage(Image.open("mocha.png")),  # New image for Mocha
    "Macchiato": ImageTk.PhotoImage(Image.open("macchiato.png"))  # New image for Macchiato
}

# Create a frame to position the content closer to the top center
content_frame = tk.Frame(canvas, bg="white", relief="raised", bd=2)
content_frame.place(relx=0.5, rely=0.05, anchor="n")  # Moved to be closer to the top

# Coffee selection
coffee_var = tk.StringVar(value="Select a Coffee")
tk.Label(content_frame, text="Select a Coffee:", font=("Arial", 12), bg="white").grid(row=0, column=0, padx=10, pady=10,
                                                                                      sticky="w")
coffee_menu = ttk.Combobox(content_frame, textvariable=coffee_var, values=list(coffee_prices.keys()), state="readonly")
coffee_menu.grid(row=0, column=1, padx=10, pady=10)
coffee_menu.bind("<<ComboboxSelected>>", update_coffee_image)

# Add-ons (adjusted to ensure all are visible)
tk.Label(content_frame, text="Select Add-ons:", font=("Arial", 12), bg="white").grid(row=2, column=0, padx=10, pady=10,
                                                                                     sticky="w")
add_on_vars = {add_on: tk.BooleanVar() for add_on in add_on_prices}

# Adjust row/column weights to make more space for add-ons section
for i, add_on in enumerate(add_on_vars):
    tk.Checkbutton(content_frame, text=f"{add_on} (+${add_on_prices[add_on]:.2f})", variable=add_on_vars[add_on],
                   font=("Arial", 10), bg="white", anchor="w").grid(row=3 + i, column=0, columnspan=2, sticky="w",
                                                                    padx=10, pady=5)

# Adjusted to lower the buttons and give more space between them
tk.Button(content_frame, text="Calculate Total", command=calculate_total).grid(row=9, column=0, pady=20,
                                                                               padx=10)  # Moved down
tk.Button(content_frame, text="Clear Order", command=clear_order).grid(row=9, column=1, pady=20, padx=10)  # Moved down
tk.Button(content_frame, text="View Order History", command=show_order_history).grid(row=10, column=0, columnspan=2,
                                                                                     pady=10)

# New "Exit" button to close the application
tk.Button(content_frame, text="Exit", command=root.quit).grid(row=11, column=0, columnspan=2, pady=10)

# Result label with more padding for visibility
result_label = tk.Label(content_frame, text="", font=("Arial", 14), fg="green", bg="white")
result_label.grid(row=12, column=0, columnspan=2, pady=30)  # Increased pady to make sure it's visible

# Coffee image display
coffee_image_label = tk.Label(canvas, bg="white")
coffee_image_label.place(relx=0.5, rely=1.0, anchor="s")

# Run the application
root.mainloop()
